// Write a program to a person is eligible for voting or not. A person will be eligible to vote if his/her age is greater than or equal to 18 .
import java.util.Scanner;

/*---- Defining a custom exception class ----------------*/
class AgeException extends Exception
{
	public AgeException(String msg)
	{
		super(msg);
	}
}
/*------------------------------------------------------*/

public class VoteExample {

	public static void main(String[] args) throws AgeException
	{
		int age;
		
		//Creating object of Scanner class
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your age: ");
		age = sc.nextInt();
		
		//Checking age validity and eligibility
		if(age < 0)
		{
			//throw the exception
			throw new AgeException("Please enter a valid age.");
		}
		else if(age >= 18)
		{
			System.out.println("You are eligible to vote.");
		}
		else
		{
			System.out.println("You are not eligible to vote.");
		}
		
		//Closing scanner
		sc.close();
	}
}
