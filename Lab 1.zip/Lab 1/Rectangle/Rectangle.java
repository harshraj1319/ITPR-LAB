// Write a program to calculate the area and perimeter of a rectangle.Use custom exception and comments and taking input from th user
import java.util.Scanner;

/*---- Defining a custom exception class ----------------*/
class InvalidDimensionException extends Exception
{
	public InvalidDimensionException(String msg)
	{
		super(msg);
	}
}
/*------------------------------------------------------*/

public class Rectangle {

	public static void main(String[] args) throws InvalidDimensionException
	{
		double length, width;
		
		//Creating object of Scanner class
		Scanner sc = new Scanner(System.in);
		
		//Taking input from user
		System.out.print("Enter the length of the rectangle (in cm): ");
		length = sc.nextDouble();
		
		System.out.print("Enter the width of the rectangle (in cm): ");
		width = sc.nextDouble();
		
		//Validating dimensions
		if(length > 0 && width > 0)
		{
			System.out.println("------- Rectangle Details -------");
			System.out.println("Length : " + length + " cm");
			System.out.println("Width  : " + width + " cm");
			
			//Calculating and displaying area and perimeter
			System.out.println("------- Rectangle Area -------");
			System.out.println("Area : " + (length * width) + " sq.cm");
			System.out.println("------- Rectangle Perimeter -------");
			System.out.println("Perimeter : " + (2 * (length + width)) + " cm");
		}
		else
		{
			//Throw the exception if dimensions are invalid
			throw new InvalidDimensionException("Length and width must be positive numbers.");
		}
		
		//Closing the scanner object
		sc.close();
	}
}
