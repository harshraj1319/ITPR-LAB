/*Write a program to input any three sides of triangle.check they form triangle or not.if they form a triangle then determine the typr of triangle being formed.
*/
import java.util.Scanner;
public class triangle {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner scanner = new Scanner(System.in);
        // Prompt the user to enter the three sides of the triangle
        System.out.print("Enter the length of side a: ");
        double a = scanner.nextDouble();
        System.out.print("Enter the length of side b: ");
        double b = scanner.nextDouble();
        System.out.print("Enter the length of side c: ");
        double c = scanner.nextDouble();
        // Check if the sides form a triangle using the triangle inequality theorem
        if (a + b > c && a + c > b && b + c > a) {
            System.out.println("The sides form a triangle.");
            // Determine the type of triangle
            if (a == b && b == c) {
                System.out.println("The triangle is equilateral.");
            } else if (a == b || b == c || a == c) {
                System.out.println("The triangle is isosceles.");
            } else {
                System.out.println("The triangle is scalene.");
            }
        } else {
            System.out.println("The sides do not form a triangle.");
        }
        // Close the scanner
        scanner.close();
    }
}
