// Write a program to create an array of 15 numbers and find greatest number among then.
import java.util.Scanner;
public class Greater_Number {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[15];

        System.out.println("Enter 15 numbers:");

        // Input 15 numbers
        for (int i = 0; i < 15; i++) {
            numbers[i] = scanner.nextInt();
        }

        // Find the greatest number
        int greatest = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > greatest) {
                greatest = numbers[i];
            }
        }

        System.out.println("The greatest number among the entered numbers is: " + greatest);

        scanner.close();
    }
}
