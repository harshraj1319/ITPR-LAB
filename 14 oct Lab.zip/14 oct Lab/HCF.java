// Write a program to finout hcf of two numbers by using recursion.
import java.util.Scanner;
public class HCF {
    // Recursive method to calculate HCF
    public static int hcf(int a, int b) {
        if (b == 0) {
            return a; // Base case: HCF is found
        } else {
            return hcf(b, a % b); // Recursive case
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter the second number: ");
        int num2 = scanner.nextInt();
        
        int result = hcf(num1, num2);
        System.out.println("The HCF of " + num1 + " and " + num2 + " is: " + result);
        
        scanner.close();
    }
}