// Write a program to display first n even natural number.
import java.util.Scanner;
public class Even {
    // Recursive method to print even natural numbers
    public static void printEvenNumbers(int n, int current) {
        if (current > n) {
            return; // Base case: stop when current exceeds n
        } else {
            System.out.println(2 * current); // Print the even number
            printEvenNumbers(n, current + 1); // Recursive case
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of n to display first n even natural numbers: ");
        int n = scanner.nextInt();
        
        printEvenNumbers(n, 1); // Start printing from the first even number
        
        scanner.close();
    }
}
