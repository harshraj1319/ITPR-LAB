// Write a program to calculate addition, difference, product of two numbers.
import java.util.Scanner;
public class Arthematic {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Input first number
        System.out.print("Enter the first number: ");
        double num1 = scanner.nextDouble(); 
        // Input second number
        System.out.print("Enter the second number: ");
        double num2 = scanner.nextDouble();
        // Calculate addition
        double addition = num1 + num2;
        // Calculate difference
        double difference = num1 - num2;
        // Calculate product
        double product = num1 * num2;
        // Display the results
        System.out.printf("The addition is: %.2f%n", addition);
        System.out.printf("The difference is: %.2f%n", difference);
        System.out.printf("The product is: %.2f%n", product);
        scanner.close();
    }
}