// Write a program to calculate curved surface area, total surface area and volume of cylinder.
import java.util.Scanner;
public class Cylinder{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input radius of the cylinder
        System.out.print("Enter the radius of the cylinder: ");
        double radius = scanner.nextDouble();

        // Input height of the cylinder
        System.out.print("Enter the height of the cylinder: ");
        double height = scanner.nextDouble();

        // Calculate curved surface area
        double curvedSurfaceArea = 2 * Math.PI * radius * height;

        // Calculate total surface area
        double totalSurfaceArea = 2 * Math.PI * radius * (radius + height);

        // Calculate volume
        double volume = Math.PI * radius * radius * height;

        // Display the results
        System.out.printf("The curved surface area of the cylinder is: %.2f%n", curvedSurfaceArea);
        System.out.printf("The total surface area of the cylinder is: %.2f%n", totalSurfaceArea);
        System.out.printf("The volume of the cylinder is: %.2f%n", volume);

        scanner.close();
    }
}