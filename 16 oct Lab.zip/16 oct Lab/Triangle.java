// Write a program to calculate area and perimeter of a triangle.
import java.util.Scanner;
public class Triangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Input base of the triangle
        System.out.print("Enter the base of the triangle: ");
        double base = scanner.nextDouble();
        // Input height of the triangle
        System.out.print("Enter the height of the triangle: ");
        double height = scanner.nextDouble();
        // Input the lengths of the other two sides
        System.out.print("Enter the length of the first side: ");
        double side1 = scanner.nextDouble();
        System.out.print("Enter the length of the second side: ");
        double side2 = scanner.nextDouble();
        // Calculate area
        double area = 0.5 * base * height;
        // Calculate perimeter
        double perimeter = base + side1 + side2;
        // Display the results
        System.out.printf("The area of the triangle is: %.2f%n", area);
        System.out.printf("The perimeter of the triangle is: %.2f%n", perimeter);
        scanner.close();
    }
}